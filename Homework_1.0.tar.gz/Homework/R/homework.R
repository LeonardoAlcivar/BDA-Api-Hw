#' Homework Package
#'
#' Contains the biggerthantwo and multiple13 functions.
#'
#' @doctype package
#' @author Leonardo Alcivar Wong \email{sixter.alcivar@barcelonagse.eu}
#'
#' @name homework
NULL
