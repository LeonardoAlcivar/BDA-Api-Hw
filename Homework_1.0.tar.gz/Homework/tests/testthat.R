library(testthat)
library(Homework)

test_check("Homework")
